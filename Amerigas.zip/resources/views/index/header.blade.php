
<div class="navbar-fixed" style="z-index: 100000;">
<nav class="white" role="navigation" style="z-index: 100000;">
    <div class="nav-wrapper">
        
        <img src="images/amerigas.png" class="logoHeader" id="logo">
        <a href="eng">
            <img class="flag hide-on-med-and-down" src="images/english.jpg" style="width: 55px;">
            
        </a>
        
      <ul class="right hide-on-med-and-down">
        <li><a id="in">Inicio</a></li>
        <li><a id="quie">Quienes Somos</a></li>
        <li><a id="ali">Alianzas</a></li>
        <li><a id="pro">Productos</a></li>
        <li><a id="cur">Experiencia</a></li>
        <li><a id="cont">Contacto</a></li>  
        <li><a href="login"><i class="material-icons right">work</i><span style="display: inline">Accesar</span></a></li>
      </ul>
            
        <ul id="nav-mobile" class="side-nav">
            <li><a href="eng">English</a></li>
            <li><a id="in1">Inicio</a></li>
            <li><a id="quie1">Quienes Somos</a></li>
            <li><a id="ali1">Alianzas</a></li>
            <li><a id="pro1">Productos</a></li>
            <li><a id="cur1">Experiencias</a></li>
            <li><a id="cont1">Contacto</a></li>
            <li><a href="login"><i class="material-icons left">work</i><span style="display: inline">Accesar</span></a></li>
        </ul>
        <a href="#" data-activates="nav-mobile" class="blue-text right button-collapse"><i class="material-icons">menu</i></a> 

      
    </div>
    
  </nav>
</div>
 
