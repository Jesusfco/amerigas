    <div class="alianzas" id="alianzas"> <br><br>
        <h1 class="center" style="font-weight: 600;" >Alianzas </h1>
        <br><br>

    <div id="slider2">
            <figure>
                <img src="images/alianzas/mov/oilTanking-1.png" >
                <img src="images/alianzas/mov/mexE-1.png" >
                <img src="images/alianzas/mov/pemex-1.png">
                <img src="images/alianzas/mov/petroTech-1.png">
                <img src="images/alianzas/mov/vitol-1.png">
                <img src="images/alianzas/mov/rosarito-1.png">
                <img src="images/alianzas/mov/agri-1.png">
                <img src="images/alianzas/mov/ruilo-1.png">
                <img src="images/alianzas/mov/atc-1.png">
                <img src="images/alianzas/mov/ecos-1.png">
                
                <img src="images/alianzas/mov/oilTanking-1.png" >
                <img src="images/alianzas/mov/mexE-1.png" >
                <img src="images/alianzas/mov/pemex-1.png">
                <img src="images/alianzas/mov/petroTech-1.png">
                
            </figure>
	</div>
        <br><br><br>
        <br><br>
    </div>

