<div class="container" id="quienes"> 
        <br><br>
      <h1 class="center fat" >¿Quienes Somos? </h1>
    <div class="section somos row">        
        <div class="col s12 m6">
            <h3 class="center fat">Misión</h3>
        <p>Nuestro propósito o razón de ser va mas allá de generar riqueza.  
           Nuestra Empresa nació para crear y desarrollar proyectos energéticos 
           que resuelvan de manera integral las expectativas y necesidades de 
           nuestros Clientes y del Gobierno Mexicano; proyectos que generen 
           soluciones beneﬁciosas para todas las partes interesadas en los mismos,
           que generen empleos e infraestructura suﬁciente para tener Empresas 
           e Instituciones de Gobierno altamente productivas, y que den como 
           resultado un País prospero,  y un mejor nivel de vida para los 
           habitantes de nuestro Pais, que es Mexico</p> 
        </div>
        
        <div class="col s12 m6">
            <h3 class="center fat">Visión</h3>
            <p> Ser reconocido por la sociedad como una organización capaz, responsable, productiva, innovadora y con amplia conciencia social </p>
        </div>            
    </div>
</div>      
@if(isset($mov))
@else
<div class="parallax-container">
    <div class="parallax"><img src="images/paral1.jpg"></div>
</div>
@endif
<div class="container">
        <center>
            <h3 class="fat">POLITICAS</h3>
            <ul id="staggered-test">
                <li style="opacity: 0"><h5 class="light">• Nuestra Empresa se rige a traves de un Consejo de Administracion, por medio del cual se toman todas las decisiones relevantes y donde participan todas las partes interesadas en el negocio.</h5></li><br>
                <li style="opacity: 0"><h5 class="light">• Nuestro Empresa opera bajo los preceptos de Honestidad, Transparencia, Eficacia, Rentabilidad, Calidad y Trabajo en Equipo.</h5></li><br>
                <li style="opacity: 0"><h5 class="light">• La plena satisfaccion de nuestros Clientes es la base y prioridad de nuestra Empresa.</h5></li><br>
                <li style="opacity: 0"><h5 class="light">• Los activos mas importantes de nuestra Empresa: Nuestros compañeros de trabajo.</h5></li><br>
                <li style="opacity: 0"><h5 class="light">• La Seguridad, Salud y Proteccion Ambiental son responsabilidad de todos y condicion de empleo.</h5></li><br>
            </ul>
        </center>
</div>
