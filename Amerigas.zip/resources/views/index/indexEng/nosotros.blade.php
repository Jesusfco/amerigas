<div class="container" id="quienes"> 
    <br><br><br>
    <h1 class="center fat" >ABOUT US </h1>
    <div class="section somos row">
        
        <div class="col s12 m6">
            <h3 class="center fat">Mision</h3>
            <p>Our purpose goes beyond making proﬁt; our company was born to create and develop energy projects that help solve all needs and expectations of our clients and the federal government; to create projects that end in the result of solutions and beneﬁts for all parties, to create highly productive employment and Infrastructure and thus improving the quality of life of the people of this Country. </p> 
        </div>
        
        <div class="col s12 m6">
            <h3 class="center fat">Vision</h3>
            <p> Be recognized by the society as an organization capable, responsible, productive, innovative and with social concern </p>
        </div>            

    </div>
</div>
@if(isset($mov))
@else
<div class="parallax-container">
    <div class="parallax"><img src="images/paral1.jpg"></div>
</div>
@endif

<div class="container">
        <center>
            <h3 class="fat">STATEMENTS</h3>
            <ul id="staggered-test">
                <li style="opacity: 0"><h5 class="light">• Our Company is governed by a Board of Directors, by means of which all relevant decisions are made and where all the parties interested in the business participate.</h5></li><br>
                <li style="opacity: 0"><h5 class="light">• Our Company operates under the precepts of Honesty, Transparency, Efficiency, Profitability, Quality and Teamwork.</h5></li><br>
                <li style="opacity: 0"><h5 class="light">• The full satisfaction of our Clients is the basis and priority of our Company.</h5></li><br>
                <li style="opacity: 0"><h5 class="light">• The most important assets of our Company: Our co-workers.</h5></li><br>
                <li style="opacity: 0"><h5 class="light">• Safety, Health and Environmental Protection are everyone's responsibility and condition of employment.</h5></li><br>
            </ul>
        </center>
</div>